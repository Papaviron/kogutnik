<?php
session_start();

if (isset($_POST['loginrej'])) //sprawdzenie czy form jest wypelniony
{
	$is_valid = true;  //zalozenie walidacji
	$loginrej = $_POST['loginrej'];  //sprawdzanie loginu
	if ((strlen($loginrej) < 3) || (strlen($loginrej) > 20)) {
		$is_valid = false;
		$_SESSION['e_loginrej'] = "Nick musi posiadać od 3 do 20 znaków!";
	}
	if (ctype_alnum($loginrej) == false) {
		$is_valid = false;
		$_SESSION['e_loginrej'] = "Nick może składać się tylko z liter i cyfr (bez polskich znaków)";
	}
	//sprawdzanie hasla
	$haslo1 = $_POST['haslo1'];
	$haslo2 = $_POST['haslo2'];

	if ((strlen($haslo1) < 8) || (strlen($haslo1) > 20)) {
		$is_valid = false;
		$_SESSION['e_haslo'] = "Hasło musi posiadać od 8 do 20 znaków!";
	}

	if ($haslo1 != $haslo2) {
		$is_valid = false;
		$_SESSION['e_haslo'] = "Podane hasła nie są identyczne!";
	}
	//haszowanie hasla
	$haslo_hash = password_hash($haslo1, PASSWORD_DEFAULT);
	//echo $haslo_hash; exit();
	//zatwierdzenie regulaminu
	if (!isset($_POST['regulamin'])) {
		$is_valid = false;
		$_SESSION['e_regulamin'] = "Potwierdź akceptację regulaminu!";
	}

	//Czy nick jest już zarezerwowany?
	require_once "connect.php";
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	$rezultat = $polaczenie->query("SELECT id FROM user WHERE user_name='$loginrej'");
	$ile_takich_nickow = $rezultat->num_rows;
	if ($ile_takich_nickow > 0) {
		$is_valid = false;
		$_SESSION['e_nick'] = "Istnieje już gracz o takim loginie!.";
	}
	//dodanie do bazy
	if ($is_valid == true) {
		$sql = "INSERT INTO user VALUES (NULL, '$loginrej', '$haslo_hash', '1', NULL)";
		if ($polaczenie->query($sql) === TRUE) {
			echo "Rejestracja udana";
		}
	}
	$polaczenie->close();
}


?>
<!DOCTYPE html>
<html lang="pl">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Kogutnik - rejestracja</title>
</head>

<body>
	<form method="post">
		Login: <br /> <input type="text" name="loginrej"><br />
		<?php
		if (isset($_SESSION['e_loginrej'])) {
			echo $_SESSION['e_loginrej'];
			unset($_SESSION['e_loginrej']);
		}
		if (isset($_SESSION['e_nick'])) {
			echo $_SESSION['e_nick'];
			unset($_SESSION['e_nick']);
		}

		?>
		<br />
		Haslo: <br /> <input type="password" name="haslo1"><br />
		<?php
		if (isset($_SESSION['e_haslo'])) {
			echo $_SESSION['e_haslo'];
			unset($_SESSION['e_haslo']);
		}

		?>
		<br />
		Powtorz haslo: <br /> <input type="password" name="haslo2"><br />

		<label>
			<input type="checkbox" name="regulamin" /> Akceptuję regulamin
			<br />
			<a href="Regulamin-Kogutnika.pdf"> Przeczytaj regulamin!</a>
		</label>
		<?php
		if (isset($_SESSION['e_regulamin'])) {
			echo $_SESSION['e_regulamin'];
			unset($_SESSION['e_regulamin']);
		}

		?>
		<br />
		<input type="submit" value="Zarejestruj się" />
	</form>
</body>

</html>