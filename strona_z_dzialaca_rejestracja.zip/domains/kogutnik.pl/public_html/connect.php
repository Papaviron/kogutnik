<?php
    $host="localhost";
    $db_user="jagu_kogutnik";
    $db_password="Root1237";
    $db_name="jagu_kogutnik";
?>