<?php
session_start();

require_once "connect.php";

$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);

if ($polaczenie->connect_errno != 0) {
    echo "Error: " . $polaczenie->connect_errno . "Opis: " . $polaczenie->connect_error;
} else {
    $login = $_POST['login'];
    $haslo = $_POST['haslo'];

    $login = htmlentities($login, ENT_QUOTES, "UTF-8");

    $sql = "SELECT * FROM user where user_name='$login'";

    if ($result = @$polaczenie->query($sql)) {
        $ilu_userow = $result->num_rows;
        if ($ilu_userow > 0) {
          	$wiersz = $result->fetch_assoc();
            $_SESSION['zalogowany'] = true;
			if (password_verify($haslo, $wiersz['pass'])){
            
            $_SESSION['user'] = $wiersz['user_name'];
            $_SESSION['id'] = $wiersz['user'];

            unset($_SESSION['blad']);
            $result->close();
            header('Location:stronaGlowna.php');
            }
           else {
            $_SESSION['blad'] = '<span style="color:red"> Nieprawidlowy login lub haslo </span>';
            header('Location: stronaLogowania.php');
        }
        } else {
            $_SESSION['blad'] = '<span style="color:red"> Nieprawidlowy login lub haslo </span>';
            header('Location: stronaLogowania.php');
        }
    }
    $polaczenie->close();
}
